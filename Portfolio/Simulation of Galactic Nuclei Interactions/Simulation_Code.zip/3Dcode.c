/*
3Dcode.c

By: Dylan Johnston & Miles Kopala

This code calculates the positions of 2 masses, along with their companion bodies.
The user inputs the mass initial position and initial velocity, for both bodies.
There is an option to add a disk of test particles to each of the bodies with many parameters.
*/



//Libraries used
#include <stdio.h>
#include <math.h>



//Global constants
#define RING 60 //Maximum dimension of array in number of rings
#define STAR 60 //Maximum dimension of array in number of stars per ring
#define STRL 50 //Maximum number of characters in any string
#define STATE 4 //Maximum dimension of array in position and velocity states [0=initial,1=old,2=half,3=new]
#define BODY 2 //Maximum dimension of array in number of bodies
#define COMPONENT 3 //Maximum dimension of array in components [0=x,1=y,z=2]
#define TIME 3 //Maximum dimension of time array [0=t,1=dt,2=tmax]
#define G 0.00449955 //Gravitational constant units of Pc^3 Mwm^-1 years^-2 (Mmw = mass of mikly way = 10^12 solar mass)



//List of functions

//User inputs the mass, initial separation, and initial velocity for the two bodies
//aswell as the closest approach distance, time elements and various outputfilenames
void initialize(
  char datafilename[ ],
  char gnuplotscriptname[ ],
  char scriptfilename[ ],
  int setview[ ],
  int *referenceframe,
  double *rmin,
  double m[ ],
  double r[ ][COMPONENT][STATE],
  double v[ ][COMPONENT][STATE],
  double t[ ],
  int snapshot[ ]
);

//User chooses the number of bodies with disks, the number of rings per disk, the radius of each ring, and the direction of ratation of each disk.
void diskinitialize(
  int *numberofgalaxies,
  int rotationdirection[ ],
  int numberofrings[ ],
  int ringradiuspercentage[ ][RING],
  double rmin,
  double m[ ],
  double rstar[ ][RING][STAR][COMPONENT][STATE],
  double vstar[ ][RING][STAR][COMPONENT][STATE],
  double *c
);

//subroutine which generates the position and velocities of the stars on a ring about the origin.
void ringsetup(
  int body,
  int ringnumber,
  double m,
  int ringradiuspercentage,
  double rmin,
  double rstar[ ][RING][STAR][COMPONENT][STATE],
  double vstar[ ][RING][STAR][COMPONENT][STATE],
  int rotationdirection
);

//Sets up all needed variables given the initial inputs.
void setup(
  double m[ ],
  double r[ ][COMPONENT][STATE],
  double v[ ][COMPONENT][STATE],
  double t[ ],
  int snapshot[ ],
  int numberofgalaxies,
  int numberofrings[ ],
  int ringradiuspercentage[ ][RING],
  double rstar[ ][RING][STAR][COMPONENT][STATE],
  double vstar[ ][RING][STAR][COMPONENT][STATE]
);

//Integrates over one time step using the Verlet method
void step(
  double m[ ],
  double r[ ][COMPONENT][STATE],
  double v[ ][COMPONENT][STATE],
  double t[ ],
  int snapshot[ ],
  int numberofgalaxies,
  int numberofrings[ ],
  int ringradiuspercentage[ ][RING],
  double rstar[ ][RING][STAR][COMPONENT][STATE],
  double vstar[ ][RING][STAR][COMPONENT][STATE],
  double c
);

//calculates the number of stars on a ring of given radius.
int numberofstars(
  int ringradiuspercentage
);

//sqrt(x*x+y*y+z*z) general function for finding a magnitude, including a softening constant
double magnitude(
  double x,
  double y,
  double z,
  double c
);

//gets acceleration component
double acceleration(
  double m,
  double r1,
  double r2,
  double r3,
  double c
);

//finds the largest element of an array of integers
int maxnumber(
  int integerarray[ ],
  int sizeofarray
);

//output function for data at each snapshot and ring
void dataoutput(
  FILE *fp_outdata,
  int ringnumber,
  int referenceframe,
  int numberofgalaxies,
  int numberofrings[ ],
  int ringradiuspercentage[ ][RING],
  double t[ ],
  double r[ ][COMPONENT][STATE],
  double v[ ][COMPONENT][STATE],
  double rstar[ ][RING][STAR][COMPONENT][STATE]
);

//output function for script to create multiple plots
void scriptoutput(
  FILE *fp_outscript,
  char gnuplotscriptname[ ],
  int snapshot[ ],
  int numberofrings[ ],
  int numberofgalaxies,
  double t[ ]
);

//output function for creating a plot using gnuplot
void gnuplotoutput(
  FILE *fp_outgnuplot,
  char datafilename[ ],
  int setview[ ],
  int numberofgalaxies,
  int numberofrings[ ],
  int ringradiuspercentage[ ][RING],
  int pointtype[ ],
  const char *ringcolor[ ]
);

//changes the output data so that it is in the reference frame of the first body
void centerframe(
  double r[ ][COMPONENT][STATE],
  double rstar[ ][RING][STAR][COMPONENT][STATE],
  int numberofgalaxies,
  int numberofrings[ ],
  int ringradiuspercentage[ ][RING]
);



int main(void) {
  //Variable declaration
  char datafilename[STRL], gnuplotscriptname[STRL], scriptfilename[STRL], str[STRL]; //Name of the data files, arbitrary plot generator file and bash script file which passes the various parameters to the arbitrary plot generator
  FILE *fp_outdata, *fp_outgnuplot, *fp_outscript; //Pointers to data/plot generator/ bash script file
  double m[BODY]; //Mass of central bodies
  double r[BODY][COMPONENT][STATE]; //Position of central bodies
  double v[BODY][COMPONENT][STATE]; //Velocity of central bodies
  double rstar[BODY][RING][STAR][COMPONENT][STATE]; //Position of star test particles
  double vstar[BODY][RING][STAR][COMPONENT][STATE]; //Velocity of star test particles
  double t[TIME]; //Time, max time, time step
  double rmin; //Distance of closest approach
  double c; //Softening constant
  int numberofgalaxies; //Number of galaxies
  int rotationdirection[BODY]; //Direction of rotation of each disk when looking down on xy-plane (CW or CCW)
  int numberofrings[BODY]; //Number of rings for each body
  int ringradiuspercentage[BODY][RING]; //Radius of each ring as a percentage of the closest approach
  int snapshot[TIME]; //Integer representing each snapshot in time (proportional to current time) the amount of snapshots between each output
  int setview[2]; //The set view angles in gnuplot (default is 60 and 30)
  int referenceframe; //A variable to decide what reference frame the output data is in
  int pointtype[ ] = { 7, 6}; //array for point types that are used in the gnuplot script
  const char *ringcolor[ ] = { "yellow", "green", "turquoise", "blue", "purple", "red", "orange"}; //array of strings for the colors that are used in the gnuplot script

  int i; //integer used in for loops in main function


  //All variables that are read in
  initialize( datafilename, gnuplotscriptname, scriptfilename, setview, &referenceframe, &rmin, m, r, v, t, snapshot);
  diskinitialize( &numberofgalaxies, rotationdirection, numberofrings, ringradiuspercentage, rmin, m, rstar, vstar, &c);

  //Set up all other variables
  setup( m, r, v, t, snapshot, numberofgalaxies, numberofrings, ringradiuspercentage, rstar, vstar);

  //Given initial conditions, we create a gnuplot script that will generate a specific plot
  fp_outgnuplot = fopen( gnuplotscriptname, "w");
  gnuplotoutput( fp_outgnuplot, datafilename, setview, numberofgalaxies, numberofrings, ringradiuspercentage, pointtype, ringcolor);
  fclose( fp_outgnuplot);

  //open the script file that will pass parameters into the gnuplot script file
  fp_outscript = fopen( scriptfilename, "w");

  while (t[0] < t[2]) {
    if ( (snapshot[0]%snapshot[1]) == 0) {
      for ( i = 0; i <= maxnumber( numberofrings, BODY); i++) {
        //only prints to data file if we are a multiple of the output time interval
        //seperate data filefor each ring, and one data file for the position and velocities of the 2 massive bodies
        sprintf( str, "%s%04dring%d.dat", datafilename, snapshot[0]/snapshot[1], i);
        fp_outdata = fopen( str, "w");
        //will output data in the center of mass frame, or the frame of body 1
        dataoutput( fp_outdata, i, referenceframe, numberofgalaxies, numberofrings, ringradiuspercentage, t, r, v, rstar);
        fclose( fp_outdata);
      }
    }

    //prints a line in the bash script which will pass specific parameters to the gnuplot script to create the desired plots
    scriptoutput( fp_outscript, gnuplotscriptname, snapshot, numberofrings, numberofgalaxies, t);

    //step function to calculate and update the position and velocities of all bodies and test particles
    step( m, r, v, t, snapshot, numberofgalaxies, numberofrings, ringradiuspercentage, rstar, vstar, c);
  }


  fclose( fp_outscript);
}


//initializes all variables that are read in by the user
void initialize( char datafilename[ ], char gnuplotscriptname[ ], char scriptfilename[ ], int setview[ ], int *referenceframe, double *rmin, double m[ ], double r[ ][COMPONENT][STATE], double v[ ][COMPONENT][STATE], double t[ ], int snapshot[ ]) {
  int i;

  printf("\nEnter a name for the output file -> ");
  scanf("%s", datafilename);
  printf("%s", datafilename);

  printf("\nEnter a name for the gnuplot script file -> ");
  scanf("%s", gnuplotscriptname);
  printf("%s", gnuplotscriptname);

  printf("\nEnter a name for the script file -> ");
  scanf("%s", scriptfilename);
  printf("%s", scriptfilename);

  //the default values are not set automatically, so you must enter them
  printf("\nEnter the two set view angles in gnuplot (default is 60, 30) -> ");
  for ( i = 0; i < 2; i++) {
    scanf("%d", &setview[i]);
    printf("%d", setview[i]);

  }

  printf("\nView data in the reference frame of the center of mass (0) or body 1 (1) -> ");
  scanf("%d", referenceframe);
  printf("%d", *referenceframe);

  printf("\nDistance of closest approach between bodies [units Parsecs] -> ");
  scanf("%lf", rmin);
  printf("%lf", *rmin);

  for (i = 0; i < 2; i++) {
    printf("\nBody %d", i+1);

    printf("\n\tMass [units Milky way mass] -> ");
    scanf("%lf", &m[i]);
    printf("%lf", m[i]);

    printf("\n\tInitial x position [units parsecs] -> ");
    scanf("%lf", &r[i][0][0]);
    printf("%lf", r[i][0][0]);

    printf("\n\tInitial y position [units parsecs] -> ");
    scanf("%lf", &r[i][1][0]);
    printf("%lf", r[i][1][0]);

    printf("\n\tInitial z position [units parsecs] -> ");
    scanf("%lf", &r[i][2][0]);
    printf("%lf", r[i][2][0]);

    printf("\n\tInitial x velocity [units parsecs per year] -> ");
    scanf("%lf", &v[i][0][0]);
    printf("%lf", v[i][0][0]);

    printf("\n\tInitial y velocity [units parsecs per year] -> ");
    scanf("%lf", &v[i][1][0]);
    printf("%lf", v[i][1][0]);

    printf("\n\tInitial z velocity [units parsecs per year] -> ");
    scanf("%lf", &v[i][2][0]);
    printf("%lf", v[i][2][0]);
  }

  printf("\nTime step [units years] -> ");
  scanf("%lf", &t[1]);
  printf("%lf", t[1]);

  printf("\nMaximum time [units years] -> ");
  scanf("%lf", &t[2]);
  printf("%lf", t[2]);

  printf("\nNumber of time steps between each output -> ");
  scanf("%d", &snapshot[1]);
  printf("%d", snapshot[1]);

  printf("\nInitialize ok!");

  return;
}

void diskinitialize( int *numberofgalaxies, int rotationdirection[ ], int numberofrings[ ], int ringradiuspercentage[ ][RING], double rmin, double m[ ], double rstar[ ][RING][STAR][COMPONENT][STATE], double vstar[ ][RING][STAR][COMPONENT][STATE], double *c) {
  int i, j;

  //softening constant set as 4% of the closest approach distance
  *c = 0.04 * rmin;

  printf("\nNumber of galaxies (0, 1 or 2) -> ");
  scanf("%d", numberofgalaxies);
  printf("%d", *numberofgalaxies);

  //initializes the number of rings and the radius of each ring to be 0. This is done because comparisons to these variables must be made throughout the program
  for ( i = 0; i < 2; i++) {
    numberofrings[i] = 0;
    for ( j = 0; j < 10; j++) {
      ringradiuspercentage[i][j] = 0;
    }
  }

  if (numberofgalaxies > 0) {
    for (i = 0; i < (*numberofgalaxies); i++) {
      printf("\nGalaxy %d", i + 1);

      printf("\n\tRotation direction of galaxy %d (0 = CW, 1 = CCW) -> ", i + 1);
      scanf("%d", &rotationdirection[i]);
      printf("%d", rotationdirection[i]);

      printf("\n\tNumber of rings on galaxy %d (maximum of 7) -> ", i + 1);
      scanf("%d", &numberofrings[i]);
      printf("%d", numberofrings[i]);

      //for best results the ringradius percentage should span 20 to 100 in integer multiples of 5
      printf("\n\tIn incrementing order, enter the percentage of the closest approach for the radius of each ring (20(5)100)");
      for (j = 0; j < numberofrings[i]; j++) {
        printf("\n\t\tRing %d -> ", j + 1);
        scanf("%d", &ringradiuspercentage[i][j]);
        printf("%d%% of the closest approach distance", ringradiuspercentage[i][j]);

        //set up the initial position and velocities of all particles in a ring about the origin
        ringsetup( i, j, m[i], ringradiuspercentage[i][j], rmin, rstar, vstar, rotationdirection[i]);
      }
    }
  }

  printf("\n");

  return;
}


//set up the initial position and velocities of all particles in a ring about the origin
void ringsetup( int body, int ringnumber, double m, int ringradiuspercentage, double rmin, double rstar[ ][RING][STAR][COMPONENT][STATE], double vstar[ ][RING][STAR][COMPONENT][STATE], int rotationdirection) {
  int k, l;

  double phi;
  double dphi;
  double ringradius;
  double ringvelocity;

  //the stars are set up by incrementing an angle phi around the ring
  phi = 0;
  dphi = (2 * M_PI) / ((float) numberofstars(ringradiuspercentage));
  ringradius = rmin * (ringradiuspercentage / 100.);
  ringvelocity = sqrt( (G * m) / ringradius );
  for ( k = 0; k < numberofstars(ringradiuspercentage); k++) {
    for ( l = 0; l < 3; l++) {
      rstar[body][ringnumber][k][l][0] = (((l + 1)%3)/(l + 1)) * ringradius * cos(phi - l * (M_PI / 2.));
      vstar[body][ringnumber][k][l][0] = (((l + 1)%3)/(l + 1)) * ringvelocity * sin(phi + l * (M_PI / 2.)) * pow(-1, rotationdirection + l);
    }
    //increment the angle phi
    phi = phi + dphi;
  }

  return;
}

//setup function initialized all variables that aren't inputed by the user
void setup( double m[ ], double r[ ][COMPONENT][STATE], double v[ ][COMPONENT][STATE], double t[ ], int snapshot[ ], int numberofgalaxies, int numberofrings[ ], int ringradiuspercentage[ ][RING], double rstar[ ][RING][STAR][COMPONENT][STATE], double vstar[ ][RING][STAR][COMPONENT][STATE]) {
  int i, j, k, l;

  t[0] = 0.;
  snapshot[0] = 0;

  //routine sets up the position and velocities of the two bodies such that the center of mass is always at the origin
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++) {
      r[i][j][1] = (r[i][j][0] - r[(i+1)%2][j][0])*m[(i+1)%2]/(m[i] + m[(i+1)%2]);
      v[i][j][1] = (v[i][j][0] - v[(i+1)%2][j][0])*m[(i+1)%2]/(m[i] + m[(i+1)%2]);
    }
  }

  //routine shifts the position and velocities of all test particle stars by the amount of the central body they're orbiting
  if ( numberofgalaxies != 0) {
    for (i = 0; i < numberofgalaxies; i++) {
      for (j = 0; j < numberofrings[i]; j++) {
        for (k = 0; k < numberofstars(ringradiuspercentage[i][j]); k++) {
          for (l = 0; l < 3; l++) {
            rstar[i][j][k][l][1] = rstar[i][j][k][l][0] + r[i][l][1];
            vstar[i][j][k][l][1] = vstar[i][j][k][l][0] + v[i][l][1];
          }
        }
      }
    }
  }

  return;
}

//step function calculates the new position and velocity of every particle using the Verlet method
void step(double m[ ], double r[ ][COMPONENT][STATE], double v[ ][COMPONENT][STATE], double t[ ], int snapshot[ ], int numberofgalaxies, int numberofrings[ ], int ringradiuspercentage[ ][RING], double rstar[ ][RING][STAR][COMPONENT][STATE], double vstar[ ][RING][STAR][COMPONENT][STATE], double c) {
  int i, j, k, l;
  double a[BODY][COMPONENT];
  double astar[BODY][RING][STAR][COMPONENT];

  //half step in position
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++) {
      r[i][j][2] = r[i][j][1] + 0.5*v[i][j][1]*t[1];
    }
  }
  if ( numberofgalaxies != 0) {
    for (i = 0; i < numberofgalaxies; i++) {
      for (j = 0; j < numberofrings[i]; j++) {
        for (k = 0; k < numberofstars(ringradiuspercentage[i][j]); k++) {
          for (l = 0; l < 3; l++) {
            rstar[i][j][k][l][2] = rstar[i][j][k][l][1] + 0.5*vstar[i][j][k][l][1]*t[1];
          }
        }
      }
    }
  }

  //calculates the acceleration using the half step position
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++) {
      a[i][j] =
      acceleration( m[(i+1)%2], r[i][j][2]-r[(i+1)%2][j][2], r[i][(j+1)%3][2]-r[(i+1)%2][(j+1)%3][2], r[i][(j+2)%3][2]-r[(i+1)%2][(j+2)%3][2],
      c);
    }
  }
  if ( numberofgalaxies != 0) {
    for (i = 0; i < numberofgalaxies; i++) {
      for (j = 0; j < numberofrings[i]; j++) {
        for (k = 0; k < numberofstars(ringradiuspercentage[i][j]); k++) {
          for (l = 0; l < 3; l++) {
            astar[i][j][k][l] = acceleration( m[i], rstar[i][j][k][l][2]-r[i][l][2], rstar[i][j][k][(l+1)%3][2]-r[i][(l+1)%3][2], rstar[i][j][k][(l+2)%3][2]-r[i][(l+2)%3][2], c) + acceleration( m[(i+1)%2], rstar[i][j][k][l][2]-r[(i+1)%2][l][2], rstar[i][j][k][(l+1)%3][2]-r[(i+1)%2][(l+1)%3][2], rstar[i][j][k][(l+2)%3][2]-r[(i+1)%2][(l+2)%3][2], c);
          }
        }
      }
    }
  }

  //full step calculation in velocity
  //second half step in position
  //update old position and velocities with new values
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++) {
      v[i][j][3] = v[i][j][1] + a[i][j]*t[1];
      r[i][j][3] = r[i][j][2] + 0.5*v[i][j][3]*t[1];
      //Update
      r[i][j][1] = r[i][j][3];
      v[i][j][1] = v[i][j][3];
    }
  }
  if ( numberofgalaxies != 0) {
    for (i = 0; i < numberofgalaxies; i++) {
      for (j = 0; j < numberofrings[i]; j++) {
        for (k = 0; k < numberofstars(ringradiuspercentage[i][j]); k++) {
          for (l = 0; l < 3; l++) {
            vstar[i][j][k][l][3] = vstar[i][j][k][l][1] + astar[i][j][k][l]*t[1];
            rstar[i][j][k][l][3] = rstar[i][j][k][l][2] + 0.5*vstar[i][j][k][l][3]*t[1];
            //Update
            rstar[i][j][k][l][1] = rstar[i][j][k][l][3];
            vstar[i][j][k][l][1] = vstar[i][j][k][l][3];
          }
        }
      }
    }
  }

  //increment time and snapshot
  t[0] = t[0] + t[1];
  snapshot[0] = snapshot[0] + 1;

  return;
}

//finds the number of stars at a given ringradius(percentage)
int numberofstars( int ringradiuspercentage) {
  return (3 * ringradiuspercentage) / 5;
}

//general function for finding magnitude, but includes the softening constant
double magnitude(double x, double y, double z, double c) {
  return sqrt(x*x+y*y+z*z+c*c);
}

//general function for calculation the gravitational acceleration between two bodies
double acceleration(double m, double r1, double r2, double r3, double c) {
  return -G*m*r1/pow(magnitude(r1, r2, r3, c), 3);
}

//finds the maximum number in an array of integers
int maxnumber( int integerarray[ ], int sizeofarray) {
  int i, maxnumber;

  maxnumber = integerarray[0];
  if ( sizeofarray > 1) {
    for ( i = 1; i < sizeofarray; i++) {
      if ( integerarray[i] > maxnumber) {
        maxnumber = integerarray[i];
      }
    }
  }

  return maxnumber;
}

//function to output the data for each ring to a data file
void dataoutput( FILE *fp_outdata, int ringnumber, int referenceframe, int numberofgalaxies, int numberofrings[ ], int ringradiuspercentage[ ][RING], double t[ ], double r[ ][COMPONENT][STATE], double v[ ][COMPONENT][STATE], double rstar[ ][RING][STAR][COMPONENT][STATE]) {
  int i, j, k, l;

  j = 0;
  k = 0;
  l = 1;

  //if the user wants the data in the reference frame of body one, the if statement is executed
  if ( referenceframe == 1) {
    l = 2;
    //subtracts the position of body from all data points
    centerframe( r, rstar, numberofgalaxies, numberofrings, ringradiuspercentage);
  }

  //complicated process to ensure that all of the data is outputted in the correct format, so that we always have the ring with more stars in it printing in the first two columns
  //NOTE that all distances are printed out in usings of kPc rather than Pc
  if ( ringnumber == 0) {
    fprintf( fp_outdata, "%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\n", t[0]*1.0e-3, r[0][0][l]*1.0e-3, r[0][1][l]*1.0e-3, r[0][2][l]*1.0e-3, r[1][0][l]*1.0e-3, r[1][1][l]*1.0e-3, r[1][2][l]*1.0e-3, v[0][0][1], v[0][1][1], v[0][2][1], v[1][0][1], v[1][1][1], v[1][2][1]);
  }
  else {
    if ( ringradiuspercentage[0][ringnumber-1] >= ringradiuspercentage[1][ringnumber-1]) {
      j = 1;
    }
    if ( numberofrings[0] >= numberofrings[1]) {
      k = 1;
    }
    if ( numberofrings[k] >= ringnumber) {
      for ( i = 0; i < numberofstars(ringradiuspercentage[j][ringnumber-1]); i++) {
        fprintf( fp_outdata, "%lf\t%lf\t%lf\t%lf\t%lf\t%lf\n", rstar[(j + 1) % 2][ringnumber-1][i][0][l]*1.0e-3, rstar[(j + 1) % 2][ringnumber-1][i][1][l]*1.0e-3, rstar[(j + 1) % 2][ringnumber-1][i][2][l]*1.0e-3, rstar[j][ringnumber-1][i][0][l]*1.0e-3, rstar[j][ringnumber-1][i][1][l]*1.0e-3, rstar[j][ringnumber-1][i][2][l]*1.0e-3);
      }
      for ( i = numberofstars(ringradiuspercentage[j][ringnumber-1]); i < numberofstars(ringradiuspercentage[(j + 1) % 2][ringnumber-1]); i++) {
        fprintf( fp_outdata, "%lf\t%lf\t%lf\n", rstar[(j + 1) % 2][ringnumber-1][i][0][l]*1.0e-3, rstar[(j + 1) % 2][ringnumber-1][i][1][l]*1.0e-3, rstar[(j + 1) % 2][ringnumber-1][i][2][l]*1.0e-3);
      }
    }
    else {
      for ( i = 0; i < numberofstars(ringradiuspercentage[(k + 1) % 2][ringnumber-1]); i++) {
        fprintf( fp_outdata, "%lf\t%lf\t%lf\n", rstar[(k + 1) % 2][ringnumber-1][i][0][l]*1.0e-3, rstar[(k + 1) % 2][ringnumber-1][i][1][l]*1.0e-3, rstar[(k + 1) % 2][ringnumber-1][i][2][l]*1.0e-3);
      }
    }
  }

  return;
}

//generates the bash script which when executed will pass parameters to a gnuplot script to create a plot at each specified time
void scriptoutput( FILE *fp_outscript, char gnuplotscriptname[ ], int snapshot[ ], int numberofrings[ ], int numberofgalaxies, double t[ ]) {
  int i;

  fprintf( fp_outscript, "./%s %lf %04d ", gnuplotscriptname, t[0]*1.0e-3 - 251600, snapshot[0]/snapshot[1]);
  if ( numberofgalaxies != 0) {
    for ( i = 1; i <= maxnumber( numberofrings, BODY); i++) {
      fprintf( fp_outscript, "%d ", i);
    }
  }
  fprintf( fp_outscript, "\n");

  return;
}

//script to create a plot. this will be passed parameters from the scripts file to plot the proper data
void gnuplotoutput( FILE *fp_outgnuplot, char datafilename[ ], int setview[ ], int numberofgalaxies, int numberofrings[ ], int ringradiuspercentage[ ][RING], int pointtype[ ], const char *ringcolor[ ]) {
  int i, j;

  //many parameters in this gnuplot script are not available as an input for the user, although they easily could be. Therefore certain plot parameters must be changed directly in the C code
  fprintf(fp_outgnuplot, "gnuplot <<EOS\n");
  fprintf(fp_outgnuplot, "set terminal postscript enhanced landscape color \"Times-Roman\" 14\n");
  fprintf(fp_outgnuplot, "set output '%splot$2.ps'\n", datafilename);
  fprintf(fp_outgnuplot, "set title \"time = $1 (kyears)\"\n");
  fprintf(fp_outgnuplot, "set xlabel \"x (kPc)\" offset 0,0.5,0.5\n");
  fprintf(fp_outgnuplot, "set ylabel \"y (kPc)\" offset 0.5,0,0.5\n");
  fprintf(fp_outgnuplot, "set zlabel \"z (kPc)\" offset 0.5,0.5,0\n");
  fprintf(fp_outgnuplot, "set xrange [-100.:100.]\n");
  fprintf(fp_outgnuplot, "set yrange [-100.:100.]\n");
  fprintf(fp_outgnuplot, "set zrange [-100.:100.]\n");
  fprintf(fp_outgnuplot, "set ticslevel 0.0\n");
  fprintf(fp_outgnuplot, "set grid\n");
  fprintf(fp_outgnuplot, "set view equal xyz\n");
  fprintf(fp_outgnuplot, "set view %d,%d\n", setview[0], setview[1]);
  fprintf(fp_outgnuplot, "splot ");
  //complicated process that follows a similar structure to the output data function. ensures the correct data will be plotted at each snapshot in time
  if ( numberofgalaxies != 0) {
    for ( i = 0; i < numberofrings[0]; i++) {
      j = 0;
      if ( ringradiuspercentage[0][i] >= ringradiuspercentage[1][i]) {
        j = 1;
      }
      if ( numberofrings[1] >= i) {
        fprintf(fp_outgnuplot, "'%s$2ring$%d.dat' using %d:%d:%d notitle with points ps 0.55 pt %d lc rgb '%s',\\\n", datafilename, i + 3, ((j + 3) % 4) + 1, ((j + 3) % 4) + 2, ((j + 3) % 4) + 3, pointtype[0], ringcolor[i]);
      }
      else {
        fprintf(fp_outgnuplot, "'%s$2ring$%d.dat' using 1:2:3 notitle with points ps 0.55 pt %d lc rgb '%s',\\\n", datafilename, i + 3, pointtype[0], ringcolor[i]);
      }
    }
  }
  if ( numberofgalaxies == 2) {
    for ( i = 0; i < numberofrings[1]; i++) {
      j = 0;
      if ( ringradiuspercentage[0][i] >= ringradiuspercentage[1][i]) {
        j = 1;
      }
      if ( numberofrings[0] >= i) {
        fprintf(fp_outgnuplot, "'%s$2ring$%d.dat' using %d:%d:%d notitle with points ps 0.55 pt %d lc rgb '%s',\\\n", datafilename, i + 3, 3*j + 1, 3*j + 2, 3*j + 3, pointtype[1], ringcolor[i]);
      }
      else {
        fprintf(fp_outgnuplot, "'%s$2ring$%d.dat' using 1:2:3 notitle with points ps 0.55 pt %d lc rgb '%s',\\\n", datafilename, i + 3, pointtype[1], ringcolor[i]);
      }
    }
  }
  for ( i = 1; i < 3; i++)  {
    fprintf(fp_outgnuplot, "'%s$2ring0.dat' using %d:%d:%d notitle with points ps 1.25 pt %d lc rgb 'black'", datafilename, 3*i - 1, 3*i, 3*i + 1, pointtype[i]);
    if ( i != 2) {
      fprintf(fp_outgnuplot, ",\\");
    }
    fprintf(fp_outgnuplot, "\n");
  }
  fprintf(fp_outgnuplot, "EOS\n");

  return;
}

//if the user would like to view the data in the reference frame of the first body this function will subtract the position of the first body from all other particles.
void centerframe( double r[ ][COMPONENT][STATE], double rstar[ ][RING][STAR][COMPONENT][STATE], int numberofgalaxies, int numberofrings[ ], int ringradiuspercentage[ ][RING]) {
  int i, j, k, l;

  for (i = 0; i < 2; i++) {
    for (j = 0; j < 3; j++) {
      r[i][j][2] = r[i][j][1] - r[0][j][1];
    }
  }
  if ( numberofgalaxies != 0) {
    for (i = 0; i < numberofgalaxies; i++) {
      for (j = 0; j < numberofrings[i]; j++) {
        for (k = 0; k < numberofstars(ringradiuspercentage[i][j]); k++) {
          for (l = 0; l < 3; l++) {
            rstar[i][j][k][l][2] = rstar[i][j][k][l][1] - r[0][l][1];
          }
        }
      }
    }
  }

  return;
}
