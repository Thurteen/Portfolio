function theta = ExtractEuler(C) 
format long; 
t = zeros(1,3); 

t1  =  -asin(C(3,1)); 
t2 = pi - t1; 

psi1 = atan2(C(3,2)/cos(t1), C(3,3)/cos(t1)); 
psi2 = atan2(C(3,2)/cos(t2), C(3,3)/cos(t2)); 


phi1 = atan2(C(2,1)/cos(t1),C(1,1)/cos(t1)); 
phi2 = atan2(C(2,1)/cos(t2),C(1,1)/cos(t2)); 


theta_1 = [phi1;t1;psi1 ]; 

theta_2 = [t2;phi2; psi2]; 




% c2 = sqrt(C(1,1)^2 + C(1,2)^2); 
% 
% t(2) = atan2(C(1,3),c2); 
% 
% t(3) = atan2(C(1,2), C(1,1)); 

theta = theta_1; 
end 