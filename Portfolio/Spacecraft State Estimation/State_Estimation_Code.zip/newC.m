function C = newC(om) 

global tstep; 

phi = norm(tstep.*om); 

if phi == 0 % in case om is zero
    C = eye(3); % return identity 
    
else  
a = 1/phi * (tstep*om);

C = cos(phi)*eye(3) + (1 - cos(phi))*(a*a') + sin(phi)*SkewSymmetric(a); 
end 
% if abs(det(C)) > 1.05  % to project back onto SO(3) .. leave commented
% out for now 
%     C = (C*C')*0.5*C; 
% end 

end 