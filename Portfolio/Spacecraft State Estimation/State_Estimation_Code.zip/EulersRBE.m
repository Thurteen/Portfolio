function X = EulersRBE(w,I)
global tstep

w1 = w(1);
w2 = w(2);
w3 = w(3);

dw1 = -((I(3,3) - I(2,2))/I(1,1))*w2*w3;
dw2 = -((I(1,1) - I(3,3))/I(2,2))*w1*w3;
dw3 = -((I(2,2) - I(1,1))/I(3,3))*w2*w1; 

neww1 = w1 + dw1*tstep;
neww2 = w2 + dw2*tstep;
neww3 = w3 + dw3*tstep;

X = [neww1;neww2;neww3];

end