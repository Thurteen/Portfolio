function X = Observation(w)

X = [w];

end