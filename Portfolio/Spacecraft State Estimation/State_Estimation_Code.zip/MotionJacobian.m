function X = MotionJacobian(w,I)

global tstep
    
df1dw = inv(I)*(SkewSymmetric(I*w') - SkewSymmetric(w')*I)*tstep + eye(3);
%     df2dw = 0;
%     df1dtheta = sinv(phi,theta,psi);
%     df2dtheta = sinvderiv(phi,theta,w);
    
X = df1dw;


end