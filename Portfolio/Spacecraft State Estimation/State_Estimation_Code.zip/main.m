close all
clear all
clc

% Full POSE problem
global tstep
global t
global n
global tfinal

run('ThreeAxis.m');

%% Orbital Parameters

a = 1000000; % meters
eccentricity = 0;
inclination = 0; % degrees
RAAN = 0; % degrees
omega = 0; % degrees
tp = 0; %seconds
mu = 3.986*10^14;

%% Main

x = zeros(n,3);

q = (100*0.00016*pi/180)^2;
r = (100*0.00016*pi/180)^2*10^2;

Q = q*eye(3);  % [diag(q)];
R = r*eye(3); % [diag(r)];

P0 = diag([1,1,1]);
xhat0 = [0,0,0]; %W(1,:);

xhat1 = xhat0;
P1 = P0;

ROTS = zeros(3,3*n); % save rotation matrices 

theta_0 = [0.1; 0.1; 0]; % angle with resepct to the inertial frame 
C0 = Cz(theta_0(3))*Cy(theta_0(2))*Cx(theta_0(1)); 
Cp = C0; 

SB = zeros(3,n); 

for i = 1:(n-1)
% Calculate Spacecraft Position and Velocity
%     TA(i) = 2*atan(sqrt((1+e)/(1-e))*tan(EccentricAnomaly(i)/2));
%     r = a*(1-e^2)/(1+e*cos(TA(i)));
%     v = sqrt(mu*((2/a)-(1/r));
%     R(i,1) = r*cos(TA(i));
%     R(i,2) = r*sin(TA(i));
%     RI(i,:) = Rotation313(w,inclination,RAAN)'*R(i,:);
%     V(i,1) = -sin(TA(i)) * sqrt(mu/(a*(1-e^2)));
%     V(i,2) = (cos(TA(i) + e)) * sqrt(mu/(a*(1-e^2)));
    
% Calculate Angular Velocity of Satellite
%     Thetadot(i,:) = sinv(phi,theta)*Omega(i);
    
    xhat2 = EulersRBE(xhat1,I); %xhat1;
    P2 = MotionJacobian(xhat1,I)*P1*MotionJacobian(xhat1,I)' + Q;
    H = ObservationJacobian();
    K = P2*H'*inv(H*P2*H' + R);
    xhat3 = xhat2 + K * (Wn(i,:)' - Observation(xhat2));
    P3 = (eye(3) - K*H)*P2*(eye(3)-K*H)'; + K*R*K';
    
    
    Cup = newC(xhat3); 
    
    Cn = Cup*Cp; 
    ROTS(:,i:i+2) = Cn; % save rotation matrix 
    
    Cp = Cn; % update 
    
    thetas = ExtractEuler(Cp); 
    
    ths(i) = thetas(1); 
    phis(i) = thetas(2); 
    psis(i) = thetas(3); 
    
    
    SB(:,i) = sqrt(diag(P3));
%     if i > 1 
%     if (sign(ths(i)) ~=  sign(ths(i-1))) && (abs(ths(i)) - abs(ths(i-1)) < 0.2) % if the sign is not the same - make it 
%         ths(i) = -ths(i); 
%     end 
%     
%     if sign(phis(i-1)) ~= sign(phis(i)) 
%         phis(i) = -phis(i); 
%     end 
%     
%      if sign(psis(i-1)) ~= sign(psis(i)) 
%         psis(i) = -psis(i); 
%     end 
%     
%     end 
    x(i,:) = xhat3;
    
    xhat1 = xhat3';
    P1 = P3;
      

end

%% Plotting
close all
clc

figure
plot(t,Wn(:,1),'r',t,Wn(:,2),'g',t,Wn(:,3),'b');

figure
hold on
%plot(t,W(:,1),'k',t,W(:,2),'k',t,W(:,3),'k');
plot(t,x(:,1),'r',t,x(:,2),'b',t,x(:,3),'g');
legend('pitch rate','roll rate','yaw rate');
hold off 


% 
% plot sigma bounds 
figure; 
hold on 
plot(t,3*SB(1,:),'k',t,3*SB(2,:),'k',t,3*SB(3,:),'k'); 
plot(t,-3*SB(1,:),'k',t,-3*SB(2,:),'k',t,-3*SB(3,:),'k'); 
hold off

figure 
hold on
plot(t,W(:,1) - x(:,1));
plot(t,3*SB(1,:),'k',t,-3*SB(1,:),'k');
hold off

figure 
hold on 
plot(t(2:end),ths,'r'); 
plot(t(2:end),phis,'b'); 
plot(t(2:end),psis,'g'); 

plot(t(2:end),theta_true(1,:),'c'); 
plot(t(2:end),theta_true(2,:),'p'); 
plot(t(2:end),theta_true(3,:),'y'); 
legend('pitch','roll','yaw','true pitch','true roll','true yaw'); 


